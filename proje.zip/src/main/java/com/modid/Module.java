package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
	public final String name;
	public final String category;
	public final List<Setting> settings = new ArrayList<>();
	private boolean enabled;

	protected Module(String name, String category) {
		this.name = name;
		this.category = category;
	}

	protected <T extends Setting> T add(T s) {
		settings.add(s);
		return s;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean e) {
		if (e == enabled) return;
		enabled = e;
		if (e) onEnable(); else onDisable();
	}

	public void onEnable() {}
	public void onDisable() {}
	public void onTick(MinecraftClient mc) {}
	public void onHud(DrawContext ctx, MinecraftClient mc) {}
}
