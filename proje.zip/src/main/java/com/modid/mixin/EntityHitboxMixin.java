package com.modid.mixin;

import com.modid.CombatExtras;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityHitboxMixin {
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void modid$expand(CallbackInfoReturnable<Float> cir) {
        if (!CombatExtras.HIT_BOXES.isEnabled()) return;
        Entity self = (Entity) (Object) this;
        if (!(self instanceof LivingEntity) || self == MinecraftClient.getInstance().player) return;
        if (CombatExtras.HIT_BOXES.playersOnly.get() && !(self instanceof PlayerEntity)) return;
        cir.setReturnValue(cir.getReturnValue() + (float) CombatExtras.HIT_BOXES.expand.get());
    }
}
