package com.modid;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Modules {
	public static final List<Module> ALL = new ArrayList<>();

	public static final Aura AURA = reg(new Aura());
	public static final AutoClicker AUTO_CLICKER = reg(new AutoClicker());
	public static final TargetHud TARGET_HUD = reg(new TargetHud());
	public static final Sprint SPRINT = reg(new Sprint());
	public static final Fullbright FULLBRIGHT = reg(new Fullbright());
	public static final Coordinates COORDINATES = reg(new Coordinates());

	private Modules() {}

	private static <T extends Module> T reg(T m) {
		ALL.add(m);
		return m;
	}

	public static List<Module> inCategory(String category) {
		List<Module> out = new ArrayList<>();
		for (Module m : ALL) if (m.category.equals(category)) out.add(m);
		return out;
	}

	public static boolean isEnabled(String name) {
		for (Module m : ALL) if (m.name.equals(name)) return m.isEnabled();
		return false;
	}

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if (mc.player == null || mc.world == null) return;
			for (Module m : ALL) if (m.isEnabled()) m.onTick(mc);
		});
		HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player == null) return;
			for (Module m : ALL) if (m.isEnabled()) m.onHud(ctx, mc);
		});
	}

	// ---------------------------------------------------------------- Combat

	public static class AutoClicker extends Module {
		public final Setting.Num cps = add(new Setting.Num("CPS", 10, 1, 20, 1));
		private int timer;

		public AutoClicker() {
			super("Auto Clicker", "Combat");
		}

		@Override
		public void onTick(MinecraftClient mc) {
			if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) {
				timer = 0;
				return;
			}
			long interval = Math.max(1, Math.round(20.0 / cps.get()));
			if (++timer >= interval) {
				timer = 0;
				if (mc.crosshairTarget instanceof EntityHitResult hit) {
					mc.interactionManager.attackEntity(mc.player, hit.getEntity());
					mc.player.swingHand(Hand.MAIN_HAND);
				}
			}
		}
	}

	public static class TargetHud extends Module {
		public TargetHud() {
			super("Target HUD", "Combat");
		}

		@Override
		public void onHud(DrawContext ctx, MinecraftClient mc) {
			Entity te = AURA.current != null ? AURA.current : mc.targetedEntity;
			if (!(te instanceof LivingEntity t)) return;

			int x = ctx.getScaledWindowWidth() / 2 + 20;
			int y = ctx.getScaledWindowHeight() / 2 + 20;
			ctx.fill(x, y, x + 100, y + 26, 0xAA101418);
			ctx.drawTextWithShadow(mc.textRenderer, t.getName().getString(), x + 4, y + 4, 0xFFFFFFFF);

			float ratio = Math.max(0f, Math.min(1f, t.getHealth() / t.getMaxHealth()));
			ctx.fill(x + 4, y + 17, x + 96, y + 21, 0xFF333333);
			ctx.fill(x + 4, y + 17, x + 4 + (int) (92 * ratio), y + 21, 0xFF5CF2E0);
		}
	}

	// -------------------------------------------------------------- Movement

	public static class Sprint extends Module {
		public Sprint() {
			super("Sprint", "Movement");
		}

		@Override
		public void onTick(MinecraftClient mc) {
			ClientPlayerEntity p = mc.player;
			if (p.input.movementForward > 0 && !p.isSneaking() && !p.horizontalCollision
					&& !p.isUsingItem() && p.getHungerManager().getFoodLevel() > 6) {
				p.setSprinting(true);
			}
		}
	}

	// ---------------------------------------------------------------- Render

	public static class Fullbright extends Module {
		public Fullbright() {
			super("Fullbright", "Render");
		}

		@Override
		public void onTick(MinecraftClient mc) {
			StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
			if (cur == null || cur.getDuration() < 600) {
				mc.player.addStatusEffect(new StatusEffectInstance(
						StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
			}
		}

		@Override
		public void onDisable() {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
		}
	}

	public static class Coordinates extends Module {
		public Coordinates() {
			super("Coordinates", "Render");
		}

		@Override
		public void onHud(DrawContext ctx, MinecraftClient mc) {
			ClientPlayerEntity p = mc.player;
			String s = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
			ctx.drawTextWithShadow(mc.textRenderer, s, 4, 4, 0xFF5CF2E0);
		}
	}
}
