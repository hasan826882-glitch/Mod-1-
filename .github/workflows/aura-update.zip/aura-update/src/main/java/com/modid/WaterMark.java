package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

/** Sol üstte Nursultan tarzı filigran: [WexaClient] [W] | kullanıcı | fps | ping. */
public class WaterMark extends Module {
    public final Setting.Bool iconLeft = add(new Setting.Bool("Icon Left", false));
    public final Setting.Bool info = add(new Setting.Bool("Show Info", true));

    public WaterMark() {
        super("Water Mark", "Combat");
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        var tr = mc.textRenderer;
        String name = "WexaClient";

        String extra = "";
        if (info.get()) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            extra = mc.getSession().getUsername() + "  |  " + mc.getCurrentFps() + " fps  |  " + ping + " ms";
        }

        int x = 6, y = 6, h = 18, pad = 5, box = 14;
        int nameW = tr.getWidth(name);
        int extraW = extra.isEmpty() ? 0 : tr.getWidth(extra) + 10;
        int w = pad + box + 5 + nameW + extraW + pad;

        Ui.rrect(ctx, x, y, w, h, 5, Ui.BG);
        Ui.rrect(ctx, x, y + h - 2, w, 2, 1, Ui.ACCENT); // alt şerit

        int cx = x + pad;
        if (iconLeft.get()) {
            drawBadge(ctx, tr, cx, y + 2, box);
            cx += box + 5;
            ctx.drawText(tr, name, cx, y + 5, Ui.ACCENT, true);
            cx += nameW;
        } else {
            ctx.drawText(tr, name, cx, y + 5, Ui.ACCENT, true);
            cx += nameW + 5;
            drawBadge(ctx, tr, cx, y + 2, box);
            cx += box;
        }
        if (!extra.isEmpty()) ctx.drawText(tr, extra, cx + 10, y + 5, Ui.TEXT, true);
    }

    private static void drawBadge(DrawContext ctx, net.minecraft.client.font.TextRenderer tr, int x, int y, int s) {
        Ui.rrect(ctx, x, y, s, s, 4, Ui.ACCENT);
        ctx.drawText(tr, "W", x + (s - tr.getWidth("W")) / 2, y + (s - 8) / 2, 0xFF0B0D10, false);
    }
}
