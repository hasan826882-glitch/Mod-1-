package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$hurt(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.hurtCam)) ci.cancel();
    }

    /** Totem patlama animasyonu. */
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$totem(ItemStack stack, CallbackInfo ci) {
        if (stack.isOf(Items.TOTEM_OF_UNDYING) && NoRender.on(NoRender.I.totem)) ci.cancel();
    }

    /** Spectate (creeper/örümcek vb.) ve benzeri post-process bozulma shader'ları. */
    @Inject(method = "loadPostProcessor", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$glitch(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.glitch)) ci.cancel();
    }
}
