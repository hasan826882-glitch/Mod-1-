package com.modid.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.modid.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void modid$fireHead(CallbackInfo ci) {
        NoRender n = NoRender.I;
        if (!NoRender.on(n.fire)) return;
        double h = n.fireHeight.get();
        if (h <= 0.01) {
            ci.cancel();
        } else if (h < 0.999) {
            // Alevi aşağı kaydırarak yüksekliği azalt (yaklaşık)
            RenderSystem.getModelViewStack().pushMatrix();
            RenderSystem.getModelViewStack().translate(0f, (float) (-(1.0 - h) * 0.7), 0f);
            RenderSystem.applyModelViewMatrix();
            n.firePushed = true;
        }
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"), require = 0)
    private static void modid$fireTail(CallbackInfo ci) {
        NoRender n = NoRender.I;
        if (n.firePushed) {
            RenderSystem.getModelViewStack().popMatrix();
            RenderSystem.applyModelViewMatrix();
            n.firePushed = false;
        }
    }
}
