package com.modid;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * WexaClient ClickGUI (Nursultan tarzı): solda kategoriler, sağda kartlar.
 * Sol tık: modülü aç/kapat. Sağ tık: ayarları aç/kapat. Tekerlek: kaydır.
 */
public class ModIDScreen extends Screen {

    private static final Set<Module> EXPANDED = new HashSet<>();
    private static String selected;

    private static final int HEADER = 22, ROW_BOOL = 15, ROW_MODE = 15, ROW_NUM = 22, GAP = 6, SIDE = 104;

    private final List<String> cats = new ArrayList<>();
    private int scroll;
    private Setting.Num dragNum;
    private int dragX, dragW;

    private static class Card {
        Module m;
        int col, y, h;
    }

    public ModIDScreen() {
        super(Text.literal("WexaClient"));
    }

    public static boolean isEnabled(String name) {
        return Modules.isEnabled(name);
    }

    @Override
    protected void init() {
        cats.clear();
        for (String pref : new String[]{"Combat", "Movement", "Render"}) {
            for (Module m : Modules.ALL) if (m.category.equals(pref)) { cats.add(pref); break; }
        }
        for (Module m : Modules.ALL) if (!cats.contains(m.category)) cats.add(m.category);
        if (selected == null || !cats.contains(selected)) selected = cats.isEmpty() ? "" : cats.get(0);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------ yerleşim

    private int winW() { return Math.min(450, width - 16); }
    private int winH() { return Math.min(300, height - 16); }
    private int winX() { return (width - winW()) / 2; }
    private int winY() { return (height - winH()) / 2; }
    private int cX() { return winX() + SIDE + 8; }
    private int cY() { return winY() + 30; }
    private int cW() { return winW() - SIDE - 16; }
    private int cH() { return winH() - 38; }
    private int colW() { return (cW() - GAP) / 2; }

    private static int settingH(Setting s) {
        if (s instanceof Setting.Num) return ROW_NUM;
        if (s instanceof Setting.Mode) return ROW_MODE;
        return ROW_BOOL;
    }

    private List<Card> layout() {
        List<Card> out = new ArrayList<>();
        int[] colY = {0, 0};
        for (Module m : Modules.inCategory(selected)) {
            Card c = new Card();
            c.m = m;
            int h = HEADER;
            if (EXPANDED.contains(m)) {
                h += 3;
                for (Object o : m.settings) h += settingH((Setting) o);
                h += 3;
            }
            c.h = h;
            c.col = colY[0] <= colY[1] ? 0 : 1;
            c.y = colY[c.col];
            colY[c.col] += h + GAP;
            out.add(c);
        }
        totalH = Math.max(colY[0], colY[1]);
        return out;
    }

    private int totalH;

    private int maxScroll() {
        layout();
        return Math.max(0, totalH - cH());
    }

    // ------------------------------------------------------------ çizim

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int x = winX(), y = winY(), w = winW(), h = winH();
        Ui.rrect(ctx, x, y, w, h, 8, Ui.BG);
        Ui.rrect(ctx, x, y, SIDE, h, 8, Ui.BG_DARK);
        ctx.fill(x + SIDE - 8, y, x + SIDE, y + h, Ui.BG_DARK); // sağ kenarı düzleştir

        ctx.drawText(textRenderer, "WexaClient", x + 12, y + 12, Ui.ACCENT, true);
        ctx.fill(x + 12, y + 26, x + SIDE - 12, y + 27, 0x22FFFFFF);

        int cy = y + 36;
        for (String c : cats) {
            boolean sel = c.equals(selected);
            boolean hov = mouseX >= x + 6 && mouseX < x + SIDE - 6 && mouseY >= cy && mouseY < cy + 22;
            if (sel) Ui.rrect(ctx, x + 6, cy, SIDE - 12, 22, 5, Ui.ACCENT_DIM);
            else if (hov) Ui.rrect(ctx, x + 6, cy, SIDE - 12, 22, 5, 0x18FFFFFF);
            int on = 0;
            for (Module m : Modules.inCategory(c)) if (m.isEnabled()) on++;
            ctx.drawText(textRenderer, c, x + 14, cy + 7, sel ? Ui.ACCENT : Ui.TEXT, false);
            String cnt = String.valueOf(on);
            ctx.drawText(textRenderer, cnt, x + SIDE - 14 - textRenderer.getWidth(cnt), cy + 7, Ui.DIM, false);
            cy += 26;
        }
        ctx.drawText(textRenderer, "LMB: ac/kapat", x + 12, y + h - 28, Ui.DIM, false);
        ctx.drawText(textRenderer, "RMB: ayarlar", x + 12, y + h - 17, Ui.DIM, false);

        ctx.drawText(textRenderer, selected, cX(), y + 12, Ui.TEXT, true);

        int ms = maxScroll();
        scroll = Math.max(0, Math.min(scroll, ms));
        ctx.enableScissor(cX(), cY(), cX() + cW(), cY() + cH());
        for (Card c : layout()) {
            int cx = cX() + c.col * (colW() + GAP);
            int top = cY() + c.y - scroll;
            if (top + c.h < cY() || top > cY() + cH()) continue;
            drawCard(ctx, c, cx, top, mouseX, mouseY);
        }
        ctx.disableScissor();

        if (ms > 0) { // kaydırma çubuğu
            int trackH = cH();
            int thumb = Math.max(16, trackH * trackH / (trackH + ms));
            int ty = cY() + (int) ((trackH - thumb) * (scroll / (double) ms));
            Ui.rrect(ctx, x + w - 6, ty, 2, thumb, 1, 0x66FFFFFF);
        }
    }

    private void drawCard(DrawContext ctx, Card c, int x, int y, int mx, int my) {
        int w = colW();
        boolean on = c.m.isEnabled();
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + HEADER
                && my >= cY() && my < cY() + cH();
        Ui.rrect(ctx, x, y, w, c.h, 5, hov ? 0xFF1C2026 : Ui.CARD);
        if (on) Ui.rrect(ctx, x, y + 4, 2, HEADER - 8, 1, Ui.ACCENT);

        ctx.drawText(textRenderer, c.m.name, x + 9, y + 7, on ? Ui.TEXT : Ui.DIM, false);
        drawSwitch(ctx, x + w - 26, y + 6, on);

        if (!EXPANDED.contains(c.m)) return;
        int sy = y + HEADER + 3;
        for (Object o : c.m.settings) {
            Setting s = (Setting) o;
            drawSetting(ctx, s, x, sy, w);
            sy += settingH(s);
        }
    }

    private void drawSwitch(DrawContext ctx, int x, int y, boolean on) {
        Ui.rrect(ctx, x, y, 20, 10, 5, on ? Ui.ACCENT : Ui.TRACK);
        Ui.rrect(ctx, on ? x + 11 : x + 1, y + 1, 8, 8, 4, 0xFFFFFFFF);
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y, int w) {
        if (s instanceof Setting.Bool b) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 3, Ui.TEXT, false);
            drawSwitch(ctx, x + w - 26, y + 2, b.get());
        } else if (s instanceof Setting.Mode m) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 3, Ui.TEXT, false);
            String v = m.get();
            int vw = textRenderer.getWidth(v);
            Ui.rrect(ctx, x + w - 14 - vw - 4, y + 1, vw + 8, 12, 4, Ui.ACCENT_DIM);
            ctx.drawText(textRenderer, v, x + w - 14 - vw, y + 3, Ui.ACCENT, false);
        } else if (s instanceof Setting.Num n) {
            ctx.drawText(textRenderer, s.name, x + 9, y + 2, Ui.TEXT, false);
            String v = n.display();
            ctx.drawText(textRenderer, v, x + w - 9 - textRenderer.getWidth(v), y + 2, Ui.ACCENT, false);
            int tx = x + 9, tw = w - 18, ty = y + 14;
            Ui.rrect(ctx, tx, ty, tw, 3, 1, Ui.TRACK);
            double t = (n.get() - n.min) / Math.max(1e-9, n.max - n.min);
            int fw = (int) (tw * Math.max(0, Math.min(1, t)));
            Ui.rrect(ctx, tx, ty, Math.max(2, fw), 3, 1, Ui.ACCENT);
            Ui.rrect(ctx, tx + fw - 2, ty - 1, 5, 5, 2, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------ fare

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = winX(), y = winY();

        int cy = y + 36;
        for (String c : cats) {
            if (mx >= x + 6 && mx < x + SIDE - 6 && my >= cy && my < cy + 22) {
                selected = c;
                scroll = 0;
                return true;
            }
            cy += 26;
        }

        if (mx < cX() || mx >= cX() + cW() || my < cY() || my >= cY() + cH()) return super.mouseClicked(mx, my, button);

        for (Card c : layout()) {
            int cx = cX() + c.col * (colW() + GAP);
            int top = cY() + c.y - scroll;
            int w = colW();
            if (mx < cx || mx >= cx + w || my < top || my >= top + c.h) continue;

            if (my < top + HEADER) {
                if (button == 0) c.m.toggle();
                else if (button == 1 && !c.m.settings.isEmpty()) {
                    if (!EXPANDED.remove(c.m)) EXPANDED.add(c.m);
                }
                return true;
            }

            int sy = top + HEADER + 3;
            for (Object o : c.m.settings) {
                Setting s = (Setting) o;
                int sh = settingH(s);
                if (my >= sy && my < sy + sh) {
                    if (s instanceof Setting.Bool b) {
                        b.toggle();
                    } else if (s instanceof Setting.Mode m) {
                        m.next();
                    } else if (s instanceof Setting.Num n) {
                        dragNum = n;
                        dragX = cx + 9;
                        dragW = w - 18;
                        setSlider(mx);
                    }
                    return true;
                }
                sy += sh;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void setSlider(double mx) {
        if (dragNum == null) return;
        double t = Math.max(0, Math.min(1, (mx - dragX) / (double) dragW));
        double v = dragNum.min + t * (dragNum.max - dragNum.min);
        if (dragNum.step > 0) v = Math.round((v - dragNum.min) / dragNum.step) * dragNum.step + dragNum.min;
        dragNum.set(Math.max(dragNum.min, Math.min(dragNum.max, v)));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragNum != null) {
            setSlider(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragNum = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (v * 18)));
        return true;
    }
}
