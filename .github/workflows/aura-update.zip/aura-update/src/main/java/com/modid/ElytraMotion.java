package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra Motion: havada sabit durma / kontrollü hız.
 * Elytra Target hedef bulduysa hedefe "dona dona" gider: menzile girince donar (vurur),
 * hedef kaçınca tekrar hamle yapar. Hedef yoksa W/S/Space/Shift ile yönetilir, tuş yoksa havada donar.
 */
public class ElytraMotion extends Module {
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.2, 0.3, 3.0, 0.1));
    public final Setting.Num stopDistance = add(new Setting.Num("Stop Distance", 2.6, 0.5, 6.0, 0.1));
    public final Setting.Bool hover = add(new Setting.Bool("Hover", true));

    private boolean frozen;

    public ElytraMotion() {
        super("Elytra Motion", "Combat");
    }

    @Override
    public void onDisable() {
        frozen = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || !p.isFallFlying() || mc.currentScreen != null) {
            frozen = false;
            return;
        }

        ElytraTarget et = ElytraTarget.I;
        if (et.isEnabled() && et.target != null && et.chasePoint != null) {
            Vec3d to = et.chasePoint.subtract(p.getPos().add(0, p.getStandingEyeHeight() * 0.5, 0));
            double dist = to.length();
            if (dist <= stopDistance.get()) frozen = true;
            else if (dist > stopDistance.get() + 1.0) frozen = false;

            if (frozen) p.setVelocity(Vec3d.ZERO);
            else p.setVelocity(to.normalize().multiply(speed.get()));
            return;
        }
        frozen = false;

        Vec3d look = p.getRotationVec(1f);
        Vec3d v = Vec3d.ZERO;
        boolean any = false;
        if (mc.options.forwardKey.isPressed()) { v = v.add(look); any = true; }
        if (mc.options.backKey.isPressed()) { v = v.subtract(look); any = true; }
        if (mc.options.jumpKey.isPressed()) { v = v.add(0, 1, 0); any = true; }
        if (mc.options.sneakKey.isPressed()) { v = v.add(0, -1, 0); any = true; }

        if (any && v.lengthSquared() > 1.0E-4) p.setVelocity(v.normalize().multiply(speed.get()));
        else if (hover.get()) p.setVelocity(Vec3d.ZERO);
    }
}
