package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.model.BipedEntityModel;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererMixin {

    @SuppressWarnings("rawtypes")
    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$armor(MatrixStack matrices, VertexConsumerProvider vcp, LivingEntity entity,
                             EquipmentSlot slot, int light, BipedEntityModel model, CallbackInfo ci) {
        if (NoRender.hideArmor(slot)) ci.cancel();
    }
}
