package com.modid;

import net.minecraft.client.gui.DrawContext;

/** Küçük çizim yardımcıları (yuvarlak köşeli dikdörtgen vb.). */
public final class Ui {
    private Ui() {}

    public static final int ACCENT = 0xFF3DDC84;      // yeşil
    public static final int ACCENT_DIM = 0x333DDC84;
    public static final int BG = 0xE6101216;
    public static final int BG_DARK = 0xF00B0D10;
    public static final int CARD = 0xFF171A1F;
    public static final int TRACK = 0xFF2A2E35;
    public static final int TEXT = 0xFFE8EAED;
    public static final int DIM = 0xFF8A9099;

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, col);
        }
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }
}
