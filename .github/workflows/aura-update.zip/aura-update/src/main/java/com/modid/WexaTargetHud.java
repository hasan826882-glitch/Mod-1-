package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** Nursultan tarzı Target HUD + hedefin üstünde dönen beyaz yuvarlak kare. */
public class WexaTargetHud extends Module {
    public final Setting.Bool marker = add(new Setting.Bool("Marker", true));
    public final Setting.Bool items = add(new Setting.Bool("Items", true));
    public final Setting.Num offX = add(new Setting.Num("Offset X", 40, -400, 400, 1));
    public final Setting.Num offY = add(new Setting.Num("Offset Y", 40, -300, 300, 1));

    private float shownHp = -1f;
    private LivingEntity last;

    public WexaTargetHud() {
        super("Target HUD", "Render");
    }

    private LivingEntity pick(MinecraftClient mc) {
        Aura a = Modules.AURA;
        if (a != null && a.isEnabled() && a.current != null && a.current.isAlive()) return a.current;
        ElytraTarget et = ElytraTarget.I;
        if (et.isEnabled() && et.target != null && et.target.isAlive()) return et.target;
        if (mc.currentScreen instanceof ChatScreen) return mc.player;
        return null;
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        LivingEntity t = pick(mc);
        if (t == null) {
            last = null;
            return;
        }
        if (t != last) {
            last = t;
            shownHp = t.getHealth();
        }
        float hp = t.getHealth() + t.getAbsorptionAmount();
        float max = Math.max(1f, t.getMaxHealth());
        shownHp += (hp - shownHp) * 0.15f;

        var tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int x = sw / 2 + (int) offX.get(), y = sh / 2 + (int) offY.get();
        int w = 150, h = 44;

        Ui.rrect(ctx, x, y, w, h, 6, Ui.BG);

        // yüz
        Ui.rrect(ctx, x + 5, y + 5, 34, 34, 5, 0xFF1D2127);
        Identifier skin = null;
        if (t instanceof AbstractClientPlayerEntity ap) skin = ap.getSkinTextures().texture();
        if (skin != null) {
            ctx.drawTexture(skin, x + 7, y + 7, 30, 30, 8f, 8f, 8, 8, 64, 64);
            ctx.drawTexture(skin, x + 7, y + 7, 30, 30, 40f, 8f, 8, 8, 64, 64);
        } else {
            String ch = t.getName().getString().isEmpty() ? "?" : t.getName().getString().substring(0, 1).toUpperCase();
            ctx.drawText(tr, ch, x + 5 + (34 - tr.getWidth(ch)) / 2, y + 18, Ui.TEXT, false);
        }

        // isim
        String name = t.getName().getString();
        while (tr.getWidth(name) > w - 52 && name.length() > 3) name = name.substring(0, name.length() - 1);
        ctx.drawText(tr, name, x + 45, y + 6, Ui.TEXT, true);

        // can çubuğu
        float ratio = MathHelper.clamp(shownHp / max, 0f, 1f);
        int bx = x + 45, by = y + 19, bw = w - 52, bh = 6;
        Ui.rrect(ctx, bx, by, bw, bh, 3, Ui.TRACK);
        int col = ratio > 0.5f ? Ui.mix(0xFFE5C14A, Ui.ACCENT, (ratio - 0.5f) * 2f) : Ui.mix(0xFFE5483A, 0xFFE5C14A, ratio * 2f);
        Ui.rrect(ctx, bx, by, Math.max(4, (int) (bw * ratio)), bh, 3, col);

        ctx.drawText(tr, String.format("%.1f HP", hp), x + 45, y + 29, Ui.DIM, false);

        // eşyalar
        if (items.get()) {
            ItemStack[] st = {
                    t.getEquippedStack(EquipmentSlot.HEAD), t.getEquippedStack(EquipmentSlot.CHEST),
                    t.getEquippedStack(EquipmentSlot.LEGS), t.getEquippedStack(EquipmentSlot.FEET),
                    t.getMainHandStack()};
            int ix = x + 45 + 48;
            for (ItemStack s : st) {
                if (!s.isEmpty()) {
                    MatrixStack m = ctx.getMatrices();
                    m.push();
                    m.translate(ix, y + 27, 0);
                    m.scale(0.6f, 0.6f, 1f);
                    ctx.drawItem(s, 0, 0);
                    m.pop();
                }
                ix += 10;
            }
        }

        if (marker.get() && t != mc.player) drawMarker(ctx, mc, t);
    }

    private void drawMarker(DrawContext ctx, MinecraftClient mc, LivingEntity t) {
        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d pos = t.getLerpedPos(td).add(0, t.getHeight() * 0.5, 0);
        double[] s = project(mc, pos);
        if (s == null) return;

        int sh = mc.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double size = MathHelper.clamp((sh / 2.0) / tan * (t.getHeight() * 0.9) / s[2], 14.0, 90.0);
        int r = (int) (size / 2);
        float ang = (System.currentTimeMillis() % 2400L) / 2400f * 360f;

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(s[0], s[1], 0);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(ang));
        int c = 0xFFFFFFFF, th = 2;
        ctx.fill(-r + 3, -r, r - 3, -r + th, c);
        ctx.fill(-r + 3, r - th, r - 3, r, c);
        ctx.fill(-r, -r + 3, -r + th, r - 3, c);
        ctx.fill(r - th, -r + 3, r, r - 3, c);
        ctx.fill(-r + 1, -r + 1, -r + 3, -r + 3, c);
        ctx.fill(r - 3, -r + 1, r - 1, -r + 3, c);
        ctx.fill(-r + 1, r - 3, -r + 3, r - 1, c);
        ctx.fill(r - 3, r - 3, r - 1, r - 1, c);
        m.pop();
    }

    /** Dünya -> ekran (ölçekli koordinat). {x, y, derinlik} ya da null. */
    private static double[] project(MinecraftClient mc, Vec3d pos) {
        var cam = mc.gameRenderer.getCamera();
        Vec3d d = pos.subtract(cam.getPos());
        Vec3d fwd = Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        Vec3d right = fwd.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-6) return null;
        right = right.normalize();
        Vec3d up = right.crossProduct(fwd);

        double f = d.dotProduct(fwd);
        if (f < 0.1) return null;
        double sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double sx = sw / 2.0 + (d.dotProduct(right) / (f * tan * (sw / sh))) * (sw / 2.0);
        double sy = sh / 2.0 - (d.dotProduct(up) / (f * tan)) * (sh / 2.0);
        return new double[]{sx, sy, f};
    }
}
